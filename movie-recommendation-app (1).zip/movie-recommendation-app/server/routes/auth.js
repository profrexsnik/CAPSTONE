const router = require('express').Router();
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const User = require('../models/User');

router.post('/register', async (req, res) => {
  const hashed = await bcrypt.hash(req.body.password, 10);
  const newUser = new User({ ...req.body, password: hashed });
  await newUser.save();
  res.status(201).send('User registered');
});

router.post('/login', async (req, res) => {
  const user = await User.findOne({ email: req.body.email });
  if (!user) return res.status(404).send('User not found');
  const isValid = await bcrypt.compare(req.body.password, user.password);
  if (!isValid) return res.status(400).send('Invalid password');
  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET, { expiresIn: '1d' });
  res.json({ token, user });
});

module.exports = router;