import axios from 'axios';
const API = axios.create({ baseURL: 'http://localhost:5000/api/movies' });
export const searchMovies = (query) => API.get(`/search?q=${query}`);
