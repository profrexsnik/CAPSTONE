import { useState } from 'react';
import { searchMovies } from '../api/tmdb';

const Search = () => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);

  const handleSearch = async () => {
    const res = await searchMovies(query);
    setResults(res.data.results);
  };

  return (
    <div>
      <input onChange={(e) => setQuery(e.target.value)} />
      <button onClick={handleSearch}>Search</button>
      <ul>{results.map(movie => <li key={movie.id}>{movie.title}</li>)}</ul>
    </div>
  );
};

export default Search;